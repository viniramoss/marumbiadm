const XLSX = require('xlsx');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { Chart, registerables } = require('chart.js');
Chart.register(...registerables);

let chartInstance = null;

/* Navegação */
function setupNavigation() {
  const links = {
    dashboard: document.getElementById('nav-dashboard'),
    settings: document.getElementById('nav-settings')
  };
  const pages = {
    dashboard: document.getElementById('page-dashboard'),
    settings: document.getElementById('page-settings')
  };
  function activate(page) {
    Object.values(links).forEach(l => l.classList.remove('active'));
    Object.values(pages).forEach(p => p.classList.remove('visible'));
    links[page].classList.add('active');
    pages[page].classList.add('visible');
    if (page === 'dashboard') loadDashboard(); // reload when returning
  }
  links.dashboard.addEventListener('click', e => { e.preventDefault(); activate('dashboard'); });
  links.settings.addEventListener('click', e => { e.preventDefault(); activate('settings'); });
}

/* Tema */
function setupTheme() {
  const checkbox = document.getElementById('themeToggle');
  const label = document.getElementById('themeLabel');
  const saved = localStorage.getItem('theme') || 'light';
  checkbox.checked = saved === 'dark';
  applyTheme(checkbox.checked);
  checkbox.addEventListener('change', () => {
    applyTheme(checkbox.checked);
    localStorage.setItem('theme', checkbox.checked ? 'dark' : 'light');
  });
  function applyTheme(dark) {
    document.body.classList.toggle('dark', dark);
    label.textContent = dark ? 'Tema Escuro' : 'Tema Claro';
  }
}

/* Utilidades */
function findXlsx() {
  const desktop = path.join(os.homedir(), 'Desktop');
  const file = fs.readdirSync(desktop).find(f => f.toLowerCase().endsWith('.xlsx'));
  return file ? path.join(desktop, file) : null;
}
function toNumber(val) {
  if (val == null || val === '') return 0;
  if (typeof val === 'number') return val;
  let s = String(val).replace(/[R$€£¥\s]/g,'');
  if (s.includes('.') && s.includes(',')) s = s.replace(/\./g,'').replace(',', '.');
  else if (s.includes(',')) s = s.replace(/\./g,'').replace(',', '.');
  else { const p = s.split('.'); if (p.length > 2) { const d = p.pop(); s = p.join('') + '.' + d; } }
  return parseFloat(s) || 0;
}
function parseDate(v) {
  if (v instanceof Date) return v;
  if (typeof v === 'number') { const d = XLSX.SSF.parse_date_code(v); return new Date(d.y, d.m-1, d.d); }
  const m = String(v).match(/(\d{1,2})[\/-](\d{1,2})[\/-](\d{2,4})/);
  if (m) { let [ , d, mo, y ] = m.map(Number); if (y < 100) y += 2000; return new Date(y, mo-1, d); }
  return new Date(NaN);
}
function weekOfMonth(date) {
  const weekdayFirst = new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  return Math.ceil((date.getDate() + weekdayFirst) / 7);
}

/* Dashboard */
function loadDashboard() {
  const file = findXlsx();
  if (!file) { document.getElementById('card').textContent = 'Nenhum .xlsx encontrado.'; return; }
  const wb = XLSX.readFile(file, { cellDates: true });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });

  // header
  let headerRow = 0;
  for (let i = 0; i < Math.min(20, rows.length); i++) {
    const low = rows[i].map(c => String(c || '').toLowerCase());
    if (low.includes('dinheiro') && low.includes('debito')) { headerRow = i; break; }
  }
  const header = rows[headerRow].map(h => String(h).toLowerCase());
  const idx = {
    date: header.indexOf('data'),
    dinheiro: header.indexOf('dinheiro'),
    debito: header.indexOf('debito'),
    credito: header.indexOf('credito'),
    pix: header.indexOf('pix'),
    voucher: header.indexOf('voucher')
  };

  let total = 0;
  const weeks = {};

  for (let i = headerRow + 1; i < rows.length; i++) {
    const row = rows[i];
    if (!row || row.every(c => c === '')) continue;
    const dt = parseDate(row[idx.date]);
    if (isNaN(dt)) continue;
    const w = weekOfMonth(dt);
    if (!weeks[w]) weeks[w] = 0;
    const sum = ['dinheiro','debito','credito','pix','voucher'].map(k => toNumber(row[idx[k]])).reduce((a,b)=>a+b,0);
    total += sum; weeks[w] += sum;
  }

  renderCard(total);
  renderChart(weeks);
}

function renderCard(total) {
  document.getElementById('card').innerHTML = `
    <h2>FATURAMENTO MENSAL</h2>
    <p>R$ ${total.toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2})}</p>
  `;
}

function renderChart(weeks) {
  const labels = Object.keys(weeks).map(Number).sort((a,b)=>a-b).map(w=>'Semana '+w);
  const values = labels.map(l => weeks[parseInt(l.split(' ')[1])]);

  if (chartInstance) chartInstance.destroy();
  const ctx = document.getElementById('chart').getContext('2d');
  chartInstance = new Chart(ctx, {
    type: 'line',
    data: { labels, datasets:[{ data: values, tension:.3, pointRadius:4, borderWidth:2, label:'Faturamento por Semana' }] },
    options: {
      maintainAspectRatio: false,
      plugins: { legend:{display:false}, tooltip:{callbacks:{label:c=>'R$ '+c.parsed.y.toLocaleString('pt-BR',{minimumFractionDigits:2})}} },
      scales: {
        y: { beginAtZero:true, ticks:{callback:v=>'R$ '+v.toLocaleString('pt-BR')} }
      }
    }
  });
}

/* Init */
document.addEventListener('DOMContentLoaded', () => {
  setupNavigation();
  setupTheme();
  loadDashboard(); // initial
});
