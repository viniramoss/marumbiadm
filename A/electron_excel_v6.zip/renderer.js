const XLSX = require('xlsx');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { Chart, registerables } = require('chart.js');
Chart.register(...registerables);

// ==== utilidades ====
function findXlsxOnDesktop() {
  const desktop = path.join(os.homedir(), 'Desktop');
  const files = fs.readdirSync(desktop).filter(f => f.toLowerCase().endsWith('.xlsx'));
  return files.length ? path.join(desktop, files[0]) : null;
}
// converte valores monetários para número
function toNumber(raw) {
  if (raw == null || raw === '') return 0;
  if (typeof raw === 'number') return raw;
  let s = String(raw).trim();
  s = s.replace(/[R$\$€£¥\s]/g, '');
  if (s.includes('.') && s.includes(',')) s = s.replace(/\./g, '').replace(',', '.');
  else if (s.includes(',')) s = s.replace(/\./g, '').replace(',', '.');
  else {
    const p = s.split('.');
    if (p.length > 2) { const dec = p.pop(); s = p.join('') + '.' + dec; }
  }
  const num = parseFloat(s);
  return isNaN(num) ? 0 : num;
}
// parse de datas em vários formatos (excel serial, Date, string dd/mm/aa)
function parseDate(value) {
  if (value instanceof Date) return value;
  if (typeof value === 'number') {
    const d = XLSX.SSF.parse_date_code(value);
    return new Date(d.y, d.m - 1, d.d);
  }
  if (typeof value === 'string') {
    const m = value.match(/(\d{1,2})[\/-](\d{1,2})[\/-](\d{2,4})/);
    if (m) {
      let [ , d, mo, y ] = m.map(Number);
      if (y < 100) y += 2000;
      return new Date(y, mo - 1, d);
    }
  }
  return new Date(NaN);
}
// calcula a "semana do mês" alinhada a DOM-SAB (domingo a sábado)
function weekOfMonth(date) {
  const firstDayWeekday = new Date(date.getFullYear(), date.getMonth(), 1).getDay(); // 0=Dom
  const shiftedDate = date.getDate() + firstDayWeekday;
  return Math.ceil(shiftedDate / 7);
}

// ==== processamento principal ====
function loadData() {
  const filePath = findXlsxOnDesktop();
  if (!filePath) {
    document.body.innerHTML = '<p style="color:red;text-align:center">Nenhum arquivo .xlsx encontrado na Área de Trabalho.</p>';
    return;
  }
  const wb = XLSX.readFile(filePath, { cellDates: true });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const table = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });

  // encontrar cabeçalho
  let headerIdx = 0;
  for (let i = 0; i < Math.min(20, table.length); i++) {
    const lower = table[i].map(c => String(c || '').toLowerCase().trim());
    if (lower.includes('dinheiro') && lower.includes('debito')) { headerIdx = i; break; }
  }
  const headers = table[headerIdx].map(h => String(h).toLowerCase().trim());
  const idx = {
    data: headers.indexOf('data'),
    dinheiro: headers.indexOf('dinheiro'),
    debito: headers.indexOf('debito'),
    credito: headers.indexOf('credito'),
    pix: headers.indexOf('pix'),
    voucher: headers.indexOf('voucher')
  };

  // Totais
  let totalMes = 0;
  const weeklyTotals = {};

  for (let i = headerIdx + 1; i < table.length; i++) {
    const row = table[i];
    if (!row || row.every(c => c === '')) continue;

    const dateVal = row[idx.data];
    const date = parseDate(dateVal);
    if (isNaN(date)) continue;

    const wk = weekOfMonth(date);
    if (!weeklyTotals[wk]) weeklyTotals[wk] = 0;

    const rowSum = ['dinheiro','debito','credito','pix','voucher']
      .map(k => toNumber(row[idx[k]]))
      .reduce((a, b) => a + b, 0);

    totalMes += rowSum;
    weeklyTotals[wk] += rowSum;
  }

  renderCard(totalMes);
  renderChart(weeklyTotals);
}

// ==== renderização ====
function renderCard(total) {
  const el = document.getElementById('card');
  el.innerHTML = `
    <h2>FATURAMENTO MENSAL</h2>
    <p>R$ ${total.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
  `;
}

function renderChart(weeklyTotals) {
  const weeks = Object.keys(weeklyTotals).map(Number).sort((a,b)=>a-b);
  const labels = weeks.map(w => 'Semana ' + w);
  const values = weeks.map(w => weeklyTotals[w]);

  const ctx = document.getElementById('chart').getContext('2d');
  new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        data: values,
        label: 'Faturamento por Semana',
        tension: 0.3,
        fill: false,
        pointRadius: 4,
        borderWidth: 2
      }]
    },
    options: {
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: c => 'R$ ' + c.parsed.y.toLocaleString('pt-BR', { minimumFractionDigits: 2 })
          }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: { callback: v => 'R$ ' + v.toLocaleString('pt-BR') }
        }
      }
    }
  });
}

document.addEventListener('DOMContentLoaded', loadData);
